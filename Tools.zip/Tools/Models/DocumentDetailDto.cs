﻿
namespace SearchDocMCF7.DTO
{
    class DocumentDetailDto
    {
        public string Content { get; set; }
        public byte Type { get; set; }
        public string Row { get; set; }
        public string Column { get; set; }
        public long SheetId { get; set; }
    }
}
