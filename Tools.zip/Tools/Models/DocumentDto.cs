﻿namespace SearchDocMCF7.DTO
{
    public class DocumentDto
    {
        public bool Check { get; set; }
        public string Path { get; set; }
        public string FileName { get; set; }
    }
}
