﻿namespace SearchDocMCF7.DTO
{
    class SheetDto
    {
        public string Name { get; set; }
        public long DocumentId { get; set; }
    }
}
