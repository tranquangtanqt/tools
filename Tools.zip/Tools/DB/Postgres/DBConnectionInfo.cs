﻿using Npgsql;
using System;

namespace SearchDocMCF7.DB.Postgres
{
    class DBConnectionInfo
    {
        public NpgsqlConnection m_Connect;
        public NpgsqlTransaction m_Transaction;
        public string m_ConnectString;
        public Exception m_Exception;

        public DBConnectionInfo()
        {
            m_ConnectString = string.Empty;
        }

        public DBConnectionInfo(string connectionString)
        {
            m_ConnectString = connectionString;
        }
    }
}
