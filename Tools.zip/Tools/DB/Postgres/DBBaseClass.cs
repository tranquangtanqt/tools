﻿using Npgsql;
using SearchDocMCF7.Common;
using System;
using System.Configuration;
using System.Data;
using System.Diagnostics;

namespace SearchDocMCF7.DB.Postgres
{
    class DBBaseClass
    {
        public DBConnectionInfo g_DBConnect;

        public DBBaseClass()
        {
            string connectString = String.Format("Server={0};Port={1};Database={2};Userid={3};password={4};",
                                           ConfigurationManager.AppSettings[Constants.CONFIG_IP_SERVER],
                                           ConfigurationManager.AppSettings[Constants.CONFIG_PORT],
                                           ConfigurationManager.AppSettings[Constants.CONFIG_DB_NAME],
                                           ConfigurationManager.AppSettings[Constants.CONFIG_USER_ID],
                                           ConfigurationManager.AppSettings[Constants.CONFIG_USER_PASSWORD]);

            g_DBConnect = new DBConnectionInfo(connectString);
        }

       /// <summary>
       /// 
       /// </summary>
       /// <returns></returns>
        public int ConnectDB()
        {
            try
            {
                g_DBConnect.m_Connect = new NpgsqlConnection(g_DBConnect.m_ConnectString);
                if (g_DBConnect.m_Connect.State == ConnectionState.Closed)
                {
                    g_DBConnect.m_Connect.Open();
                    return Constants.CONST_SUCCESS;
                }
            }
            catch (Exception ex)
            {
                g_DBConnect.m_Exception = ex;
                var st = new StackTrace();
                var sf = st.GetFrame(1);
                LogCmn.LogException(this.GetType().Name, sf.GetMethod().Name, ex);
            }
            return Constants.CONST_FAIL;
        }
    }
}