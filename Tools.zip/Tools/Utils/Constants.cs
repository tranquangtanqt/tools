﻿namespace SearchDocMCF7.Common
{
    class Constants
    {
        #region App-Config
        public const string CONFIG_IP_SERVER = "IP_SERVER";
        public const string CONFIG_PORT = "PORT";
        public const string CONFIG_DB_NAME = "DB_NAME";
        public const string CONFIG_USER_ID = "USER_ID";
        public const string CONFIG_USER_PASSWORD = "USER_PASSWORD";
        public const string CONFIG_LOG_FILE = "LOG_FILE";
        public const string CONFIG_LOG_DIR = "LOG_DIR";
        public const string LOG_EXTENSION = ".log";
        public const string CONFIG_PATH_DOC = "PATH_DOC";
        #endregion

        #region App-Config
        public const string LOG_LEVEL_DEBUG = "Debug";
        public const string LOG_LEVEL_INFOMATION = "Infomation";
        public const string LOG_LEVEL_TRACE = "Trace";
        public const string LOG_LEVEL_WARNING = "Warning";
        public const string LOG_LEVEL_ERROR = "Error";
        #endregion

        #region Format
        public const string FORMAT_YYYYMMDD = "yyyyMMdd";
        public const string FORMAT_YYYYMMDD_HHMMSSFF = "yyyy/MM/dd HH:mm:ss fff";
        #endregion

        #region "Common Database PostgreSQL execute"
        public const int CONST_SUCCESS = 0;
        public const int CONST_FAIL = -1;
        public const int CONST_EXECUTENONQUERY = 0;
        public const int CONST_EXECUTESCALAR = 1;
        public const int CONST_EXECUTEREADER = 2;
        public const int CONST_IN_STORE = 1;
        public const int CONST_OUT_STORE = 2;
        #endregion
    }
}