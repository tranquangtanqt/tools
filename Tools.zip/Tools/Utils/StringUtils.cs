﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchDocMCF7.Utils
{
    internal class StringUtils
    {
        public static bool IsUnnecessaryCharacter(string str)
        {
            str = str.Trim();
            if (str.Length == 0)
            {
                return true;
            }
            if (str.Equals("#REF!"))
            {
                return true;
            }
            //Regex r = new Regex(@"[-）〃※]");

            //return r.IsMatch(str);

            return false;
        }
    }
}
