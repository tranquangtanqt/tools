﻿using SearchDocMCF7.Common;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;

namespace SearchDocMCF7.Utils
{
    internal class FileUtils
    {
        public static string GetLogFileName()
        {
            string logFileName = ConfigurationManager.AppSettings[Constants.CONFIG_LOG_FILE];
            if (String.IsNullOrEmpty(logFileName))
            {
                throw new ApplicationException(String.Format("Log file name not found"));
            }

            string logFileDir = ConfigurationManager.AppSettings[Constants.CONFIG_LOG_DIR];
            if (String.IsNullOrEmpty(logFileDir))
            {
                throw new ApplicationException(String.Format("Log file directory not found"));
            }

            if (logFileDir.EndsWith("\\"))
            {
                logFileDir += "\\";
            }
            string newLogFileName = String.Concat(logFileName, "_", DateTime.Now.ToString(Constants.FORMAT_YYYYMMDD), Constants.LOG_EXTENSION);
            return String.Concat(logFileDir, newLogFileName);
        }

        /// <summary>
        /// GetFiles
        /// </summary>
        /// <param name="documentPath"></param>
        /// <returns></returns>
        public static List<FileInfo> GetFiles(string documentPath)
        {
            List<FileInfo> fileInfos = new List<FileInfo>();
            var directories = Array.Empty<string>();

            try
            {
                fileInfos.AddRange(new DirectoryInfo(documentPath).GetFiles("*.*", SearchOption.TopDirectoryOnly)
                    .Where(s => s.Name.EndsWith(".xlsx") || s.Name.EndsWith(".xls"))
                    // Not get file Temp
                    .Where(str => !str.Name.Contains(@"~$")));
                directories = Directory.GetDirectories(documentPath);
            }
            catch (UnauthorizedAccessException ex)
            {
                LogCmn.WriteLog(ex.ToString());
            }

            foreach (var directory in directories)
            {
                try
                {
                    fileInfos.AddRange(GetFiles(directory));
                }
                catch (Exception ex)
                {
                    LogCmn.WriteLog(ex.ToString());
                }
            }

            return fileInfos;
        }

        public static string GetStandardPath(string path)
        {
            if (String.IsNullOrEmpty(path))
            {
                return String.Empty;
            }

            path = path.Replace("\\", "/");

            if (path[0] == '/')
            {
                path = path.Remove(0, 1);
            }

            if (path[path.Length - 1] == '/')
            {
                path = path.Remove(path.Length - 1);
            }

            return path.Replace("\\", "/");
        }
    }
}
