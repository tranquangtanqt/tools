﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchDocMCF7.Common
{
    public static class LogCmn
    {
        public enum LogLevel
        {
            /// <summary>
            /// Debug
            /// </summary>
            LevelDebug,
            /// <summary>
            /// Information
            /// </summary>
            LevelInformation,
            /// <summary>
            /// Trace
            /// </summary>
            LevelTrace,
            /// <summary>
            /// Warning
            /// </summary>
            LevelWarning,
            /// <summary>
            /// Error
            /// </summary>
            LevelError
        }

        /// <summary>
        /// Main Write log function
        /// </summary>
        /// <param name="level"></param>
        /// <param name="className"></param>
        /// <param name="methodName"></param>
        /// <param name="msg"></param>
        public static void WriteLog(LogLevel level, string className, string methodName, string msg)
        {
            string logInfo = null;
            switch (level)
            {
                case LogLevel.LevelDebug:
                    logInfo = Constants.LOG_LEVEL_DEBUG;
                    break;
                case LogLevel.LevelInformation:
                    logInfo = Constants.LOG_LEVEL_INFOMATION;
                    break;
                case LogLevel.LevelTrace:
                        logInfo = Constants.LOG_LEVEL_TRACE;
                    break;
                case LogLevel.LevelWarning:
                        logInfo = Constants.LOG_LEVEL_WARNING;
                    break;
                case LogLevel.LevelError:
                    logInfo = Constants.LOG_LEVEL_ERROR;
                    break;
            }

            WriteLogStrings(logInfo, className, methodName, msg);
        }

        public static void WriteLogStrings(string level, string className, string methodName, string msg)
        {
            // Validate parameter
            if (className == null)
            {
                throw new ArgumentNullException("Class Name cannot be empty.", "ClassName");
            }

            if (methodName == null)
            {
                throw new ArgumentException("Method Name cannot be empty", "MethodName");
            }
            if (msg == null)
            {
                throw new ArgumentNullException("Message content cannot be empty", "msg");
            }

            string[] arr = new string[3];
            arr[0] = level;
            arr[1] = className;
            arr[2] = methodName;
            arr[3] = msg;
            WriteLog(String.Join(", ", arr));
        }
       
        /// <summary>
        /// Write content into log file
        /// </summary>
        /// <param name="msg"></param>
        public static void WriteLog(string msg)
        {
            string logFile = Utils.GetLogFileName();
            string logFileDir = ConfigurationManager.AppSettings[Constants.CONFIG_LOG_DIR];

            // Check if existed log file
            if(!Directory.Exists(logFileDir))
            {
                Directory.CreateDirectory(logFileDir);
            }

            string log = String.Concat( DateTime.Now.ToString(Constants.FORMAT_YYYYMMDD_HHMMSSFF), ", ", msg);

            // Initial StreamWriter
            FileStream stream = null;
            try
            {
                // Create a FileStream with mode CreateNew  
                stream = new FileStream(logFile, FileMode.Append);
                // Create a StreamWriter from FileStream  
                using (StreamWriter writer = new StreamWriter(stream, Encoding.UTF8))
                {
                    writer.WriteLine(log);
                }
            }
            finally
            {
                if (stream != null)
                    stream.Dispose();
            }
        }

        /// <summary>
        /// Log exceptions when they occured
        /// </summary>
        /// <param name="TypeName"></param>
        /// <param name="ActionName"></param>
        /// <param name="ex"></param>
        public static void LogException(string TypeName, string ActionName, Exception ex)
        {
            WriteLog(LogLevel.LevelTrace, TypeName, ActionName, ex.Message + System.Environment.NewLine + ex.StackTrace);
        }
    }
}
