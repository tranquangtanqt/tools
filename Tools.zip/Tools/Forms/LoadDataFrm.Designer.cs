﻿
namespace SearchDocMCF7.FORM
{
    partial class LoadDataFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.txtXlsxTemp = new System.Windows.Forms.TextBox();
            this.btnConvertExtentionFile = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPathDatabase = new System.Windows.Forms.TextBox();
            this.dgvFile = new System.Windows.Forms.DataGridView();
            this.Check = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Path = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FileName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnLoadFile = new System.Windows.Forms.Button();
            this.btnResetData = new System.Windows.Forms.Button();
            this.btnLoadData = new System.Windows.Forms.Button();
            this.btnEditPathDoc = new System.Windows.Forms.Button();
            this.txtPathDoc = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFile)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.txtXlsxTemp);
            this.panel2.Controls.Add(this.btnConvertExtentionFile);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.txtPathDatabase);
            this.panel2.Controls.Add(this.dgvFile);
            this.panel2.Controls.Add(this.btnLoadFile);
            this.panel2.Controls.Add(this.btnResetData);
            this.panel2.Controls.Add(this.btnLoadData);
            this.panel2.Controls.Add(this.btnEditPathDoc);
            this.panel2.Controls.Add(this.txtPathDoc);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(18, 18);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1395, 851);
            this.panel2.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 92);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 20);
            this.label3.TabIndex = 14;
            this.label3.Text = "xlsx tạm";
            // 
            // txtXlsxTemp
            // 
            this.txtXlsxTemp.Location = new System.Drawing.Point(172, 89);
            this.txtXlsxTemp.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtXlsxTemp.Name = "txtXlsxTemp";
            this.txtXlsxTemp.Size = new System.Drawing.Size(1000, 26);
            this.txtXlsxTemp.TabIndex = 13;
            // 
            // btnConvertExtentionFile
            // 
            this.btnConvertExtentionFile.Location = new System.Drawing.Point(172, 126);
            this.btnConvertExtentionFile.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnConvertExtentionFile.Name = "btnConvertExtentionFile";
            this.btnConvertExtentionFile.Size = new System.Drawing.Size(224, 35);
            this.btnConvertExtentionFile.TabIndex = 12;
            this.btnConvertExtentionFile.Text = "Chuyển đổi file sang .xlsx";
            this.btnConvertExtentionFile.UseVisualStyleBackColor = true;
            this.btnConvertExtentionFile.Click += new System.EventHandler(this.btnConvertExtentionFile_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(38, 52);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 20);
            this.label2.TabIndex = 11;
            this.label2.Text = "File DB";
            // 
            // txtPathDatabase
            // 
            this.txtPathDatabase.Location = new System.Drawing.Point(172, 49);
            this.txtPathDatabase.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtPathDatabase.Name = "txtPathDatabase";
            this.txtPathDatabase.Size = new System.Drawing.Size(1000, 26);
            this.txtPathDatabase.TabIndex = 10;
            // 
            // dgvFile
            // 
            this.dgvFile.AllowUserToAddRows = false;
            this.dgvFile.AllowUserToDeleteRows = false;
            this.dgvFile.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFile.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Check,
            this.Path,
            this.FileName});
            this.dgvFile.Location = new System.Drawing.Point(42, 193);
            this.dgvFile.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dgvFile.Name = "dgvFile";
            this.dgvFile.ReadOnly = true;
            this.dgvFile.RowHeadersWidth = 62;
            this.dgvFile.Size = new System.Drawing.Size(1318, 577);
            this.dgvFile.TabIndex = 8;
            // 
            // Check
            // 
            this.Check.FillWeight = 40F;
            this.Check.HeaderText = "";
            this.Check.MinimumWidth = 8;
            this.Check.Name = "Check";
            this.Check.ReadOnly = true;
            this.Check.Width = 40;
            // 
            // Path
            // 
            this.Path.FillWeight = 400F;
            this.Path.HeaderText = "Path";
            this.Path.MinimumWidth = 8;
            this.Path.Name = "Path";
            this.Path.ReadOnly = true;
            this.Path.Width = 400;
            // 
            // FileName
            // 
            this.FileName.FillWeight = 390F;
            this.FileName.HeaderText = "FileName";
            this.FileName.MinimumWidth = 8;
            this.FileName.Name = "FileName";
            this.FileName.ReadOnly = true;
            this.FileName.Width = 390;
            // 
            // btnLoadFile
            // 
            this.btnLoadFile.Location = new System.Drawing.Point(42, 126);
            this.btnLoadFile.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnLoadFile.Name = "btnLoadFile";
            this.btnLoadFile.Size = new System.Drawing.Size(112, 35);
            this.btnLoadFile.TabIndex = 7;
            this.btnLoadFile.Text = "Load file";
            this.btnLoadFile.UseVisualStyleBackColor = true;
            this.btnLoadFile.Click += new System.EventHandler(this.btnLoadFile_Click);
            // 
            // btnResetData
            // 
            this.btnResetData.Location = new System.Drawing.Point(1220, 85);
            this.btnResetData.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnResetData.Name = "btnResetData";
            this.btnResetData.Size = new System.Drawing.Size(141, 35);
            this.btnResetData.TabIndex = 5;
            this.btnResetData.Text = "Reset data";
            this.btnResetData.UseVisualStyleBackColor = true;
            this.btnResetData.Click += new System.EventHandler(this.btnResetData_Click);
            // 
            // btnLoadData
            // 
            this.btnLoadData.Location = new System.Drawing.Point(50, 780);
            this.btnLoadData.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnLoadData.Name = "btnLoadData";
            this.btnLoadData.Size = new System.Drawing.Size(138, 35);
            this.btnLoadData.TabIndex = 4;
            this.btnLoadData.Text = "Load data";
            this.btnLoadData.UseVisualStyleBackColor = true;
            this.btnLoadData.Click += new System.EventHandler(this.btnLoadData_Click);
            // 
            // btnEditPathDoc
            // 
            this.btnEditPathDoc.Location = new System.Drawing.Point(1220, 10);
            this.btnEditPathDoc.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnEditPathDoc.Name = "btnEditPathDoc";
            this.btnEditPathDoc.Size = new System.Drawing.Size(141, 35);
            this.btnEditPathDoc.TabIndex = 2;
            this.btnEditPathDoc.Text = "Change path";
            this.btnEditPathDoc.UseVisualStyleBackColor = true;
            this.btnEditPathDoc.Click += new System.EventHandler(this.btnEditPathDoc_Click);
            // 
            // txtPathDoc
            // 
            this.txtPathDoc.Location = new System.Drawing.Point(172, 13);
            this.txtPathDoc.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtPathDoc.Name = "txtPathDoc";
            this.txtPathDoc.Size = new System.Drawing.Size(1000, 26);
            this.txtPathDoc.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 13);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Thư mục doc";
            // 
            // UcLoadDataFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel2);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "UcLoadDataFrm";
            this.Size = new System.Drawing.Size(1434, 888);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFile)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPathDoc;
        private System.Windows.Forms.Button btnEditPathDoc;
        private System.Windows.Forms.Button btnLoadData;
        private System.Windows.Forms.Button btnResetData;
        private System.Windows.Forms.Button btnLoadFile;
        private System.Windows.Forms.DataGridView dgvFile;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Check;
        private System.Windows.Forms.DataGridViewTextBoxColumn Path;
        private System.Windows.Forms.DataGridViewTextBoxColumn FileName;
        private System.Windows.Forms.TextBox txtPathDatabase;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnConvertExtentionFile;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtXlsxTemp;
    }
}