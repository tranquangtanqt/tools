﻿using System;
using System.Windows.Forms;

namespace SearchDocMCF7.FORM
{
    public partial class MainFrm : Form
    {
        public MainFrm()
        {
            InitializeComponent();
        }

        private void btnLoadData_Click(object sender, EventArgs e)
        {
            LoadDataFrm frm = new LoadDataFrm();
            frm.ShowDialog();
        }
    }
}
