﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace SearchDocMCF7.FORM
{
    public partial class EnviromentFrm : Form
    {
        public EnviromentFrm()
        {
            InitializeComponent();
        }

        private void EnviromentFrm_Load(object sender, EventArgs e)
        {
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "SystemInfo.xml");

            XDocument doc = XDocument.Load(path);

            var systemInfo = doc.Descendants("SystemInfo").FirstOrDefault();

            if (systemInfo != null)
            {
                string excelPath = systemInfo.Element("EXCEL_PATH")?.Value;
                string excelPathTemp = systemInfo.Element("EXCEL_PATH_XLSX_TEM")?.Value;
                string excelPathDatabase = systemInfo.Element("EXCEL_PATH_DATABASE")?.Value;

                txtExcelPath.Text = excelPath;
                txtExcelPathTemp.Text = excelPathTemp;
                txtExcelPathDatabase.Text = excelPathDatabase;
            }


            //Edit file xml
            //systemInfo.Element("LANGUAGE").Value = "JPN_1";

            //doc.Save(path);
        }

        private void btnExcelSave_Click(object sender, EventArgs e)
        {
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "SystemInfo.xml");

            XDocument doc = XDocument.Load(path);

            var systemInfo = doc.Descendants("SystemInfo").FirstOrDefault();

            if (systemInfo != null)
            {
                string excelPath = txtExcelPath.Text;
                string excelPathTemp = txtExcelPathTemp.Text;
                string excelPathDatabase = txtExcelPathDatabase.Text;

                systemInfo.Element("EXCEL_PATH").Value = excelPath;
                systemInfo.Element("EXCEL_PATH_XLSX_TEM").Value = excelPathTemp;
                systemInfo.Element("EXCEL_PATH_DATABASE").Value = excelPathDatabase;

                doc.Save(path);

                MessageBox.Show("Lưu thành công");
            }
        }
    }
}
