﻿using Aspose.Cells;
using OfficeOpenXml;
using OfficeOpenXml.Drawing;
using OfficeOpenXml.Style;
using SearchDocMCF7.Common;
using SearchDocMCF7.DAO;
using SearchDocMCF7.DTO;
using SearchDocMCF7.Utils;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;

namespace SearchDocMCF7.FORM
{
    public partial class LoadDataFrm : Form
    {
        DocumentDetailDao documentDetailDao = new DocumentDetailDao();
        SheetDao sheetDao = new SheetDao();
        DocumentDao documentDao = new DocumentDao();

        public LoadDataFrm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            string path = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "SystemInfo.xml");

            XDocument doc = XDocument.Load(path);

            var systemInfo = doc.Descendants("SystemInfo").FirstOrDefault();

            if (systemInfo != null)
            {
                string excelPath = systemInfo.Element("EXCEL_PATH")?.Value;
                string excelPathTemp = systemInfo.Element("EXCEL_PATH_XLSX_TEM")?.Value;
                string excelPathDatabase = systemInfo.Element("EXCEL_PATH_DATABASE")?.Value;

                txtPathDoc.Text = excelPath;
                txtXlsxTemp.Text = excelPathTemp;
                txtPathDatabase.Text = excelPathDatabase;
            }

            //string pathDoc = Utils.GetStandardPath(ConfigurationManager.AppSettings[Constants.CONFIG_PATH_DOC]);
            //txtPathDoc.Text = pathDoc;
            txtPathDoc.Enabled = false;
            txtPathDatabase.Enabled = false;
            txtXlsxTemp.Enabled = false;
            dgvFile.RowHeadersVisible = false;
            //dgvFile.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            //dgvFile.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dgvFile.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        }

        private void btnEditPathDoc_Click(object sender, EventArgs e)
        {
            if(btnEditPathDoc.Text == "Edit path")
            {
                txtPathDoc.Enabled = true;
                btnEditPathDoc.Text = "Save";
            } else if (btnEditPathDoc.Text == "Save")
            {
                txtPathDoc.Enabled = false;
                btnEditPathDoc.Text = "Edit path";
            }
        }

        private void btnResetData_Click(object sender, EventArgs e)
        {
            DBConnection db = new DBConnection(txtPathDatabase.Text);
            db.OpenConnection();
            try
            {
                MainDao mainDao = new MainDao();
                mainDao.CreateDatabase(db);
                MessageBox.Show("Done");
            }
            catch (Exception ex)
            {
                LogCmn.WriteLog(ex.ToString());
                MessageBox.Show("Error");
            }
            finally
            {
                db.CloseConnection();
            }
        }

        private void btnLoadFile_Click(object sender, EventArgs e)
        {
            dgvFile.Rows.Clear();
            List<FileInfo> files = new List<FileInfo>();
            files = FileUtils.GetFiles(txtPathDoc.Text);
            foreach(FileInfo file in files)
            {
                DocumentDto fileDto = new DocumentDto();
                fileDto.Check = false;
                fileDto.FileName = file.Name;
                string path = FileUtils.GetStandardPath(file.DirectoryName).Replace(txtPathDoc.Text, String.Empty); ;
                fileDto.Path = FileUtils.GetStandardPath(path);
                dgvFile.Rows.Add(fileDto.Check, fileDto.Path, fileDto.FileName);
            }
        }

        private void btnLoadData_Click(object sender, EventArgs e)
        {
            DBConnection db = new DBConnection(txtPathDatabase.Text);
            db.OpenConnection();
            try
            {
                if (dgvFile.Rows.Count > 0)
                {
                    foreach (DataGridViewRow row in dgvFile.Rows)
                    {
                        DocumentDto documentDto = new DocumentDto();
                        string path = row.Cells[1].Value.ToString(); ;
                        documentDto.Path = path;
                        string fileName = row.Cells[2].Value.ToString();
                        documentDto.FileName = fileName;
                        documentDao.Insert(documentDto);
                        long documentId = db.GetLastIdInsert();

                        if (String.IsNullOrEmpty(path))
                        {
                            path = txtPathDoc.Text + "/";
                        }
                        else
                        {
                            path = txtPathDoc.Text + "/" + path;
                        }

                        ReadContentFileWithEPPlus(db, path, fileName, documentId);

                    }
                }
                MessageBox.Show("Done");
            } catch (Exception ex)
            {
                LogCmn.WriteLog(ex.ToString());
                MessageBox.Show("Error");
            } finally
            {
                db.CloseConnection();
            }
        }

        private void ReadContentFileWithEPPlus(DBConnection db, string path, string fileName, long documentId)
        {
            if (System.IO.Path.GetExtension(fileName).Equals(".xls", StringComparison.OrdinalIgnoreCase))
            {
                String tempPath = txtXlsxTemp.Text;
                string nameOnly = System.IO.Path.GetFileNameWithoutExtension(fileName);
                path = tempPath + "/" + nameOnly + ".xlsx";

            }

            // path to your excel file
            FileInfo fileInfo = new FileInfo(path);

            ExcelPackage package = new ExcelPackage(fileInfo);
            ExcelWorksheets worksheets = package.Workbook.Worksheets;

            foreach (ExcelWorksheet worksheet in worksheets)
            {
                // get number of rows and columns in the sheet
                var dimension = worksheet.Dimension;
                if (null != dimension)
                {
                    int rows = worksheet.Dimension.End.Row;
                    int columns = worksheet.Dimension.End.Column;

                    // Insert sheet name
                    StringBuilder sql = new StringBuilder();
                    SheetDto sheetDto = new SheetDto();
                    sheetDto.Name = worksheet.Name;
                    sheetDto.DocumentId = documentId;
                    sheetDao.Insert(sheetDto);
                    db.ExecuteQuery(sql.ToString());
                    long sheetId = db.GetLastIdInsert();
                    //LogCmn.WriteLog("Tên sheet: " + worksheet.Name);

                    for (int row = 1; row <= rows; row++)
                    {
                        for (int column = 1; column <= columns; column++)
                        {
                            object cellVal = worksheet.Cells[row, column].Value;
                            if (null != cellVal)
                            {
                                string content = worksheet.Cells[row, column].Value.ToString();
                                if (StringUtils.IsUnnecessaryCharacter(content))
                                {
                                    continue;
                                }
                                DocumentDetailDto documentDetailDto = new DocumentDetailDto();
                                documentDetailDto.Content = content;
                                documentDetailDto.Type = 1;
                                documentDetailDto.Row = (row).ToString();
                                documentDetailDto.Column = ExcelUtils.GetExcelColumnName(column);
                                documentDetailDto.SheetId = sheetId;
                                
                                documentDetailDao.Insert(documentDetailDto);
                                //LogCmn.WriteLog("Text: " + content);
                            }
                        }
                    }

                    foreach (var drawing in worksheet.Drawings)
                    {
                        var type = drawing.GetType();
                        if (type.ToString().Equals("OfficeOpenXml.Drawing.ExcelShape"))
                        {
                            ExcelShape shape = (ExcelShape)drawing;
                            if (shape.RichText != null && shape.RichText.Count > 0)
                            {
                                StringBuilder builder = new StringBuilder();
                                foreach (ExcelParagraph item in shape.RichText)
                                {
                                    builder.Append(item.Text);
                                }

                                String content = builder.ToString();
                                if (StringUtils.IsUnnecessaryCharacter(content))
                                {
                                    continue;
                                }

                                DocumentDetailDto documentDetailDto = new DocumentDetailDto();
                                documentDetailDto.Content = content;
                                documentDetailDto.Type = 2;
                                documentDetailDto.Row = null;
                                documentDetailDto.Column = null;
                                Type type1 = shape.From.GetType();
                                if(type1.ToString().Equals("OfficeOpenXml.Drawing.ExcelDrawing+ExcelPosition"))
                                {
                                    documentDetailDto.Row = (shape.From.Row + 1).ToString();
                                    documentDetailDto.Column = ExcelUtils.GetExcelColumnName(shape.From.Column + 1);
                                }
                                documentDetailDto.SheetId = sheetId;
                                documentDetailDao.Insert(documentDetailDto);
                                LogCmn.WriteLog("Object: " + content);
                            }
                        }
                    }
                }
            }
        }

        public string Decrypt(string cipher, string iv, string key)
        {
            try
            {
                using (RijndaelManaged rijndael = new RijndaelManaged())
                {
                    rijndael.BlockSize = 128;
                    rijndael.KeySize = 128;
                    rijndael.Mode = CipherMode.CBC;
                    rijndael.Padding = PaddingMode.PKCS7;

                    rijndael.IV = Encoding.UTF8.GetBytes(iv);
                    rijndael.Key = Encoding.UTF8.GetBytes(key);

                    ICryptoTransform decryptor = rijndael.CreateDecryptor(rijndael.Key, rijndael.IV);

                    string plain = string.Empty;
                    using (MemoryStream mStream = new MemoryStream(System.Convert.FromBase64String(cipher)))
                    {
                        using (CryptoStream ctStream = new CryptoStream(mStream, decryptor, CryptoStreamMode.Read))
                        {
                            using (StreamReader sr = new StreamReader(ctStream))
                            {
                                plain = sr.ReadLine();

                            }
                        }
                    }
                    return plain;
                }
            }
            catch (CryptographicException)
            {
                return "";
            }

        }

        private void btnConvertExtentionFile_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dgvFile.Rows)
            {
                
                string path = row.Cells[1].Value.ToString();
                string fileName = row.Cells[2].Value.ToString();
                if (System.IO.Path.GetExtension(fileName).Equals(".xls", StringComparison.OrdinalIgnoreCase))
                {
                    

                    var workbook = new Workbook($@"{path}/{fileName}");

                    string nameOnly = System.IO.Path.GetFileNameWithoutExtension(fileName);
                    String newFile = $@"{txtXlsxTemp.Text}/{nameOnly}.xlsx";
                    workbook.Save(newFile, SaveFormat.Xlsx);
                }
            }
        }
    }
}
