﻿using SearchDocMCF7.Common;
using SearchDocMCF7.DTO;
using System;
using System.Text;

namespace SearchDocMCF7.DAO
{
    class DocumentDao
    {
        public void Insert(DocumentDto documentDto)
        {
            try
            {
                StringBuilder sql = new StringBuilder();
                sql.Append(" INSERT INTO DOCUMENTS ");
                sql.Append("    (PATH, NAME) VALUES ( ");
                sql.Append(" @path, @name ");
                sql.Append(")");
                var insertCmd = DBConnection.connection.CreateCommand();
                insertCmd.CommandText = sql.ToString();
                insertCmd.Parameters.AddWithValue("path", documentDto.Path);
                insertCmd.Parameters.AddWithValue("name", documentDto.FileName);
                insertCmd.ExecuteNonQuery();
                LogCmn.WriteLog(sql.ToString());
            }
            catch (Exception ex)
            {
                LogCmn.WriteLog(ex.ToString());
            }
        }
    }
}
