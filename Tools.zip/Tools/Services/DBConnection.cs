﻿using SearchDocMCF7.Common;
using System;
using System.Data;
using System.Data.SQLite;

namespace SearchDocMCF7.DAO
{
    class DBConnection
    {
        private SQLiteConnection connection;
        private SQLiteTransaction transaction;
        public SQLiteCommand cmd;

        public DBConnection(string _databasePath)
        {
            connection = new SQLiteConnection($"Data Source={_databasePath};Version=3;");
        }

        public void ExecuteQuery(string sql)
        {
            using (var cmd = new SQLiteCommand(sql, connection))
            {
                if (transaction != null)
                    cmd.Transaction = transaction;

                cmd.ExecuteNonQuery();
            }
        }

        public void OpenConnection()
        {
            if (connection.State != ConnectionState.Open )
            {
                connection.Open();
            }
                
            LogCmn.WriteLog("Connection SQL Success!");
        }

        public void CloseConnection()
        {
            try
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
                LogCmn.WriteLog("Close connection Success!");
            } catch (Exception ex)
            {
                LogCmn.WriteLog(ex.ToString());
                throw ex;
            }

        }

        public void BeginTransaction()
        {
            try
            {
                if (transaction == null)
                {
                    transaction = connection.BeginTransaction();
                    LogCmn.WriteLog("BeginTransaction!");
                }
               
            }
            catch (Exception ex)
            {
                LogCmn.WriteLog(ex.ToString());
                throw ex;
            }
        }

        public void CommitTransaction()
        {
            try
            {
                if (transaction != null)
                {
                    transaction.Commit();
                    transaction = null;
                }
            }
            catch (Exception ex)
            {
                LogCmn.WriteLog(ex.ToString());
                throw;
            }
        }

        public void RollbackTransaction()
        {
            try
            {
                transaction?.Rollback();
                transaction = null;
            }
            catch (Exception ex)
            {
                LogCmn.WriteLog(ex.ToString());
                throw ex;
            }
        }

        public long GetLastIdInsert()
        {
            try
            {
                return connection?.LastInsertRowId ?? 0;
            }
            catch (Exception ex)
            {
                LogCmn.WriteLog(ex.ToString());
                throw ex;
            }
        }
    }
}