﻿using SearchDocMCF7.Common;
using System;
using System.Text;

namespace SearchDocMCF7.DAO
{
    class MainDao
    {
        public void CreateDatabase(DBConnection db)
        {
            try
            {
                StringBuilder sql = new StringBuilder();
                // Drop table
                sql.Append("DROP TABLE IF EXISTS DOCUMENTS; ");
                db.ExecuteQuery(sql.ToString());
                LogCmn.WriteLog("Table DOCUMENTS dropped!");

                sql.Clear();
                sql.Append("DROP TABLE IF EXISTS SHEETS; ");
                db.ExecuteQuery(sql.ToString());
                LogCmn.WriteLog("Table SHEETS dropped!");

                sql.Clear();
                sql.Append("DROP TABLE IF EXISTS DOCUMENT_DETAILS; ");
                db.ExecuteQuery(sql.ToString());
                LogCmn.WriteLog("Table DOCUMENT_DETAILS dropped!");

                //Create Table
                sql.Clear();
                sql.Append("CREATE TABLE IF NOT EXISTS DOCUMENTS ( ");
                sql.Append("	ID	INTEGER NOT NULL, ");
                sql.Append("	PATH	TEXT, ");
                sql.Append("	NAME	TEXT, ");
                sql.Append("	PRIMARY KEY(ID AUTOINCREMENT) ");
                sql.Append("); ");
                db.ExecuteQuery(sql.ToString());
                LogCmn.WriteLog("Table DOCUMENTS created!");

                sql.Clear();
                sql.Append("CREATE TABLE IF NOT EXISTS SHEETS ( ");
                sql.Append("	ID	INTEGER NOT NULL, ");
                sql.Append("	NAME	TEXT, ");
                sql.Append("	DOCUMENT_ID	INTEGER NOT NULL, ");
                sql.Append("	PRIMARY KEY(ID AUTOINCREMENT) ");
                sql.Append("); ");
                db.ExecuteQuery(sql.ToString());
                LogCmn.WriteLog("Table SHEETS created!");

                sql.Clear();
                sql.Append("CREATE TABLE IF NOT EXISTS DOCUMENT_DETAILS ( ");
                sql.Append("	ID	INTEGER NOT NULL, ");
                sql.Append("	CONTENT	TEXT, ");
                sql.Append("	TYPE INTEGER, "); // Text: 1; Object 2
                sql.Append("	ROW	TEXT, ");
                sql.Append("	COLUMN	TEXT, ");
                sql.Append("	SHEET_ID	INTEGER NOT NULL, ");
                sql.Append("	PRIMARY KEY(ID AUTOINCREMENT) ");
                sql.Append("); ");
                db.ExecuteQuery(sql.ToString());
                LogCmn.WriteLog("Table DOCUMENT_DETAILS created!");

                sql.Clear();
                sql.Append(" CREATE INDEX IF NOT EXISTS document_index ON DOCUMENTS (PATH, NAME); ");
                db.ExecuteQuery(sql.ToString());
                LogCmn.WriteLog("INDEX name_index created!");

                sql.Clear();
                sql.Append(" CREATE INDEX IF NOT EXISTS sheet_index ON SHEETS (NAME); ");
                db.ExecuteQuery(sql.ToString());
                LogCmn.WriteLog("INDEX path_index created!");

                sql.Clear();
                sql.Append(" CREATE INDEX IF NOT EXISTS detail_index ON DOCUMENT_DETAILS (content); ");
                db.ExecuteQuery(sql.ToString());
                LogCmn.WriteLog("INDEX detail_content_index created!");
                db.CloseConnection();
            }
            catch (Exception ex)
            {
                db.CloseConnection();
                LogCmn.WriteLog(ex.ToString());
            }
        }
    }
}
