﻿using SearchDocMCF7.Common;
using SearchDocMCF7.DTO;
using System;
using System.Text;

namespace SearchDocMCF7.DAO
{
    class SheetDao
    {
        public void Insert(SheetDto sheetDto)
        {
            try
            {
                StringBuilder sql = new StringBuilder();
                sql.Append(" INSERT INTO SHEETS ");
                sql.Append("    (NAME, DOCUMENT_ID) VALUES( ");
                sql.Append(" @name, @documentId ");
                sql.Append(")");
                var insertCmd = DBConnection.connection.CreateCommand();
                insertCmd.CommandText = sql.ToString();
                insertCmd.Parameters.AddWithValue("name", sheetDto.Name);
                insertCmd.Parameters.AddWithValue("documentId", sheetDto.DocumentId);
                insertCmd.ExecuteNonQuery();
                LogCmn.WriteLog(sql.ToString());
            }
            catch (Exception ex)
            {
                LogCmn.WriteLog(ex.ToString());
            }
        }
    }
}
