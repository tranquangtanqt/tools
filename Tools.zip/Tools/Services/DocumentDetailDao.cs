﻿using SearchDocMCF7.Common;
using SearchDocMCF7.DTO;
using System;
using System.Text;

namespace SearchDocMCF7.DAO
{
    class DocumentDetailDao
    {
        public void Insert(DocumentDetailDto documentDetailDto)
        {
            try
            {
                StringBuilder sql = new StringBuilder();
                sql.Append(" INSERT INTO DOCUMENT_DETAILS ");
                sql.Append("    (CONTENT, TYPE, ROW, COLUMN, SHEET_ID) VALUES( ");
                sql.Append(" @content, @type, @row, @column, @sheetId");
                sql.Append(")");
                var insertCmd = DBConnection.connection.CreateCommand();
                insertCmd.CommandText = sql.ToString();
                insertCmd.Parameters.AddWithValue("content", documentDetailDto.Content);
                insertCmd.Parameters.AddWithValue("type", documentDetailDto.Type);
                insertCmd.Parameters.AddWithValue("row", documentDetailDto.Row);
                insertCmd.Parameters.AddWithValue("column", documentDetailDto.Column);
                insertCmd.Parameters.AddWithValue("sheetId", documentDetailDto.SheetId);
                insertCmd.ExecuteNonQuery();
                LogCmn.WriteLog(sql.ToString());
            }
            catch (Exception ex)
            {
                LogCmn.WriteLog(ex.ToString());
            }
        }
    }
}
