﻿using OfficeOpenXml;
using OfficeOpenXml.Drawing;
using OfficeOpenXml.Style;
using SearchDocMCF7.Common;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SQLite;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TikaOnDotNet.TextExtraction;

namespace SearchDocMCF7
{
    public partial class Form1 : Form
    {
        public static SQLiteConnection connection = new SQLiteConnection();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            //ReadContentEPPlus();
            string filePath = "D:/Project/Tranining_MCF7/SVN_DOC/MCF7_Summary_Document/M7_7013_Doc/01_ユーザ概要/02_機能関連図/M7-US-0201_M7_r02.04_全体機能関連図.xlsx";
            //Utils.ReadContentFileWithEPPlus(filePath);
            ReadContentTika(filePath);
        }

        private void ReadContentEPPlus()
        {
            // path to your excel file
            string path = "D:/Project/Tranining_MCF7/SVN_DOC/MCF7_Summary_Document/M7_7013_Doc/01_ユーザ概要/02_機能関連図/M7-US-0201_M7_r02.04_全体機能関連図.xlsx";
            FileInfo fileInfo = new FileInfo(path);

            ExcelPackage package = new ExcelPackage(fileInfo);
            ExcelWorksheet worksheet = package.Workbook.Worksheets.FirstOrDefault();

            // get number of rows and columns in the sheet
            int rows = worksheet.Dimension.End.Row; // 20
            int columns = worksheet.Dimension.End.Column; // 7

            // loop through the worksheet rows and columns
            for (int i = 1; i <= rows; i++)
            {
                for (int j = 1; j <= columns; j++)
                {
                    object cellVal = worksheet.Cells[i, j].Value;
                    if (null != cellVal)
                    {
                        string content = worksheet.Cells[i, j].Value.ToString();
                        Console.WriteLine(content);
                        LogCmn.WriteLog(content);
                    }
                }
            }

            foreach (var drawing in worksheet.Drawings)
            {
                var type = drawing.GetType();
                if (type.ToString() == "OfficeOpenXml.Drawing.ExcelShape")
                {
                    ExcelShape shape = (ExcelShape)drawing;
                    if (shape.RichText != null && shape.RichText.Count > 0)
                    {
                        foreach (ExcelParagraph item in shape.RichText)
                        {
                            Console.WriteLine("{0}", item.Text);
                            LogCmn.WriteLog(item.Text);
                        }
                    }
                }
            }
        }

        private void CreateDatabase()
        {
            try
            {
                connection.ConnectionString = "Data Source=" + ConfigurationManager.AppSettings["DatabasePath"] + ";Version=3;";
                connection.Open();
                LogCmn.WriteLog("Connection SQL Success!");

                StringBuilder sql = new StringBuilder();
                // Drop table
                sql.Append("DROP TABLE IF EXISTS DOCUMENTS; ");
                sql.Append("DROP TABLE IF EXISTS DOCUMENT_DETAILS; ");
                ExecuteData(sql.ToString());
                LogCmn.WriteLog("Table DOCUMENTS, DOCUMENT_DETAILS dropped!");
                //Create Table

                sql.Append("CREATE TABLE IF NOT EXISTS DOCUMENTS ( ");
                sql.Append("	ID	INTEGER NOT NULL, ");
                sql.Append("	PATH	TEXT, ");
                sql.Append("	PRIMARY KEY(ID AUTOINCREMENT) ");
                sql.Append("); ");
                ExecuteData(sql.ToString());
                LogCmn.WriteLog("Table DOCUMENTS created!");

                sql = new StringBuilder();
                sql.Append("CREATE TABLE IF NOT EXISTS DOCUMENT_DETAILS ( ");
                sql.Append("	ID	INTEGER NOT NULL, ");
                sql.Append("	CONTENT	TEXT, ");
                sql.Append("	ROW	INTEGER, ");
                sql.Append("	COLUMN	INTEGER, ");
                sql.Append("	ID_DOCUMENT	INTEGER NOT NULL, ");
                sql.Append("	PRIMARY KEY(ID AUTOINCREMENT) ");
                sql.Append("); ");
                ExecuteData(sql.ToString());
                LogCmn.WriteLog("Table DOCUMENT_DETAILS created!");

                sql = new StringBuilder();
                sql.Append(" CREATE UNIQUE INDEX IF NOT EXISTS path_index ON DOCUMENTS (PATH); ");
                ExecuteData(sql.ToString());
                LogCmn.WriteLog("INDEX path_index created!");

                sql = new StringBuilder();
                sql.Append(" CREATE UNIQUE INDEX IF NOT EXISTS detail_content_index ON DOCUMENT_DETAILS (content); ");
                ExecuteData(sql.ToString());
                LogCmn.WriteLog("INDEX detail_content_index created!");

                //string path = "D:/Project/Tranining_MCF7/SVN_DOC/MCF7_Summary_Document/M7_7013_Doc/01_ユーザ概要/03_機能概要";
                //List<string> files = Utils.DirSearch(path);

                //foreach (string file in files)
                //{
                //    sql = new StringBuilder();
                //    sql.Append(string.Format(" INSERT INTO DOCUMENTS (PATH) VALUES('{0}')", file.Replace(path, "")));
                //    ExecuteData(sql.ToString());
                //    LogCmn.WriteLog(file);
                //    Utils.ReadContentFileWithEPPlus(file);
                //}
            }
            catch (Exception ex)
            {
                LogCmn.WriteLog(ex.ToString());


            }

            //Utils.DirSearch("D:/Project/Tranining_MCF7/SVN_DOC/MCF7_Summary_Document/M7_7013_Doc/01_ユーザ概要");
        }

        private void ReadContentTika(string filePath)
        {
            TextExtractor textExtractor = new TextExtractor();
            TextExtractionResult docContents = textExtractor.Extract(filePath);
            LogCmn.WriteLog(docContents.Text);
        }

        public static void ExecuteData(string sql)
        {
            SQLiteCommand cmd = new SQLiteCommand(sql, connection);
            cmd.ExecuteNonQuery();
        }
    }
}
